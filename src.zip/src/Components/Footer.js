import React, { Component } from 'react';
import Home from './Footer'



function Footer() {
    return (
        <div>
<footer>
         <div class="footer">
               
      <div className="col-sm-12">
              <p id="mahi"> Copyright © 2013 All Rights Reserved </p>
            
              </div>
              
              
</div>


          </footer>
            </div>
    );
}














export default Footer;
