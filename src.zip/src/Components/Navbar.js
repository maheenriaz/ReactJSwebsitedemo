import React from 'react';
import {Link,NavLink} from 'react-router-dom'



function Navbar() {
    return (
        <div className="App">
        <nav id="nav-iop">
       <div class="nav-wrapper" style={{backgroundColor:"#f7dd78"}}>
         <a href="#" class="brand-logo" id="m-left" ><i><b> Masteree</b></i></a>
         <ul id="nav-mobile" class="right ">
          <li><NavLink to="/Home" style={{ color: '#FFF' , textDecoration:'none' }}><b>Home</b></NavLink></li>
           <li><NavLink to="#" style={{ color: '#FFF' , textDecoration:'none' }}><b>SIGN UP</b></NavLink></li>
           <li><NavLink to="/Signin" style={{ color: '#FFF' , textDecoration:'none' }}><b>SIGN IN</b></NavLink></li>
         </ul>
       </div>
     </nav>
      
       </div>

    );

}



export default Navbar;